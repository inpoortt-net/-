// ui.c —— 界面层
// 目前只有“主菜单”一个页面：顶部标题栏 + 时间 + 日期
// 时间用软件时钟（数 HAL_GetTick 的毫秒滴答），上电时从“编译那一刻”开始走
// 注意：软件时钟掉电不保存，重启后从编译时间重新开始；以后可以换成 RTC 或加按键校时
#include"ui.h"
#include"oled.h"
#include<stdlib.h>

// ================== 模块内部变量 ==================
static ui_time_t s_time;			// 当前时间
static uint32_t s_last_tick;		// 上一次刷新的滴答时刻

static const char *const s_week_names[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

// ================== 时间处理 ==================

// 判断是不是闰年
static uint8_t ui_is_leap_year(uint16_t year)
{
	if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
	{
		return 1;
	}
	return 0;
}

// 返回某年某月有多少天
static uint8_t ui_month_days(uint16_t year, uint8_t month)
{
	static const uint8_t days[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	uint8_t d = days[month - 1];

	if (month == 2 && ui_is_leap_year(year))
	{
		d = 29;
	}
	return d;
}

// 由日期算星期（蔡勒公式），返回 0=周日 ~ 6=周六
static uint8_t ui_weekday_from_date(uint16_t year, uint8_t month, uint8_t day)
{
	uint16_t y = year;
	uint8_t m = month;
	uint16_t sum;

	if (m < 3)
	{
		// 1、2 月看作上一年的 13、14 月
		m = (uint8_t)(m + 12);
		y = (uint16_t)(y - 1);
	}
	// 蔡勒公式算出来 0=周六、1=周日……最后换算成 0=周日
	sum = (uint16_t)(day + (13 * (m + 1)) / 5 + (y % 100) + (y % 100) / 4 + (y / 100) / 4 + 5 * (y / 100));
	return (uint8_t)(((sum % 7) + 6) % 7);
}

// 用编译时间给时钟上电：__DATE__ 形如 "Oct  4 2026"，__TIME__ 形如 "12:34:56"
// 好处：烧录完开机就能看到接近当前的时间，不用手动设置
static void ui_clock_init_from_build(void)
{
	const char *date_str = __DATE__;
	const char *time_str = __TIME__;
	static const char months[] = "JanFebMarAprMayJunJulAugSepOctNovDec";
	uint8_t i;

	for (i = 0; i < 12; i++)
	{
		if (date_str[0] == months[i * 3] &&
			date_str[1] == months[i * 3 + 1] &&
			date_str[2] == months[i * 3 + 2])
		{
			s_time.month = (uint8_t)(i + 1);
			break;
		}
	}
	if (i >= 12)
	{
		s_time.month = 1;	// 理论上不会发生，兜底防止月份为 0
	}
	s_time.day = (uint8_t)atoi(date_str + 4);		// "Oct  4 2026" 里的 4
	s_time.year = (uint16_t)atoi(date_str + 7);		// "Oct  4 2026" 里的 2026
	s_time.hour = (uint8_t)atoi(time_str);			// "12:34:56"
	s_time.minute = (uint8_t)atoi(time_str + 3);
	s_time.second = (uint8_t)atoi(time_str + 6);
	s_time.weekday = ui_weekday_from_date(s_time.year, s_time.month, s_time.day);
}

// 时间往前累加 seconds 秒（处理秒->分->时->日->月->年的进位，含闰年）
static void ui_clock_add_seconds(uint32_t seconds)
{
	while (seconds > 0)
	{
		seconds--;
		s_time.second++;
		if (s_time.second >= 60)
		{
			s_time.second = 0;
			s_time.minute++;
			if (s_time.minute >= 60)
			{
				s_time.minute = 0;
				s_time.hour++;
				if (s_time.hour >= 24)
				{
					s_time.hour = 0;
					s_time.weekday = (uint8_t)((s_time.weekday + 1) % 7);	// 过一天，星期加一
					s_time.day++;
					if (s_time.day > ui_month_days(s_time.year, s_time.month))
					{
						s_time.day = 1;
						s_time.month++;
						if (s_time.month > 12)
						{
							s_time.month = 1;
							s_time.year++;
						}
					}
				}
			}
		}
	}
}

// 设置时间（以后做按键校时功能时直接调这个函数）
void ui_clock_set(uint16_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t minute, uint8_t second)
{
	s_time.year = year;
	s_time.month = month;
	s_time.day = day;
	s_time.hour = hour;
	s_time.minute = minute;
	s_time.second = second;
	s_time.weekday = ui_weekday_from_date(year, month, day);
}

// 读取当前时间
const ui_time_t *ui_clock_get(void)
{
	return &s_time;
}

// ================== 画面绘制 ==================

// 把 v 按固定宽度 w 写成十进制数字（例如 v=7、w=2 写成 "07"）
static void ui_num_to_str(char *buf, uint16_t v, uint8_t w)
{
	int8_t i;

	for (i = (int8_t)(w - 1); i >= 0; i--)
	{
		buf[i] = (char)('0' + v % 10);
		v = (uint16_t)(v / 10);
	}
}

// 在第 y 行水平居中显示字符串（color=1 黑底白字；color=0 白底黑字）
static void ui_show_center(uint8_t y, const char *str, uint8_t color)
{
	uint8_t len = 0;
	uint8_t x;

	while (str[len] != '\0')
	{
		len++;
	}
	if ((uint16_t)len * 8 >= OLED_WIDTH)
	{
		x = 0;
	}
	else
	{
		x = (uint8_t)((OLED_WIDTH - len * 8) / 2);
	}
	oled_show_string(x, y, str, color);
}

// 主菜单页面：标题栏（第 0~15 行）+ 时间（第 16~31 行）+ 日期星期（第 32~47 行）
// 下半屏（第 48~63 行）先空着，以后扩充菜单项就画在这里
static void ui_main_menu_draw(void)
{
	char buf[17];
	const char *week;

	oled_clear();

	// 标题栏：白色背景 + 黑色文字
	oled_fill_rect(0, 0, OLED_WIDTH, 16, 1);
	ui_show_center(0, "MAIN MENU", 0);

	// 时间行："hh:mm:ss"
	ui_num_to_str(buf, s_time.hour, 2);
	buf[2] = ':';
	ui_num_to_str(buf + 3, s_time.minute, 2);
	buf[5] = ':';
	ui_num_to_str(buf + 6, s_time.second, 2);
	buf[8] = '\0';
	ui_show_center(16, buf, 1);

	// 日期行："yyyy-mm-dd Www"
	ui_num_to_str(buf, s_time.year, 4);
	buf[4] = '-';
	ui_num_to_str(buf + 5, s_time.month, 2);
	buf[7] = '-';
	ui_num_to_str(buf + 8, s_time.day, 2);
	buf[10] = ' ';
	week = s_week_names[s_time.weekday % 7];
	buf[11] = week[0];
	buf[12] = week[1];
	buf[13] = week[2];
	buf[14] = '\0';
	ui_show_center(32, buf, 1);

	// 把画好的内容推到屏幕
	oled_refresh();
}

// ================== 对外接口实现 ==================

// 初始化：屏幕 -> 时钟 -> 第一屏
void ui_init(void)
{
	oled_init();
	ui_clock_init_from_build();
	ui_main_menu_draw();
	s_last_tick = HAL_GetTick();
}

// 主循环任务：攒够 1 秒就走时并重画
void ui_task(void)
{
	uint32_t now = HAL_GetTick();
	uint32_t elapsed = now - s_last_tick;
	uint32_t whole_secs = elapsed / 1000;

	if (whole_secs > 0)
	{
		s_last_tick += whole_secs * 1000;	// 只前进整秒，不满 1 秒的零头留到下次
		ui_clock_add_seconds(whole_secs);
		ui_main_menu_draw();
	}
}
