// led.c —— 红/绿状态指示灯
// 红灯=PB1、绿灯=PA4（都配成推挽输出，高电平点亮；各自串了限流电阻）
// 用途：密码正确亮绿灯、错误亮红灯、锁定 30 秒期间红灯慢闪
// 非阻塞：闪烁用“看时刻”的方式在主循环里翻转，不用延时等待
#include"led.h"

// ================== 硬件测试开关 ==================
// 1 = 两个灯上电常亮（硬件体检用，查接线/极性/电阻）；
// 0 = 正常灯光逻辑（正确绿、错误红、锁定慢闪）。
// 需要体检时把这里改成 1 重新编译烧录即可。
#define LED_TEST_ALWAYS_ON	0

// ================== LED 接法选择 ==================
// 0 = 拉电流接法（默认，当前使用）：
//     GPIO → 电阻 → LED 长脚(+)，LED 短脚(−) → GND；输出【高】电平 = 亮
// 1 = 灌电流接法（想换一种接法时用）：
//     3.3V → LED 长脚(+)，LED 短脚(−) → 电阻 → GPIO；输出【低】电平 = 亮
#define LED_SINK_MODE	0

#if !LED_TEST_ALWAYS_ON
#define LED_BLINK_MS	500		// 慢闪周期：每 500ms 翻转一次

static uint8_t s_blink_on = 0;		// 慢闪模式开着吗
static uint8_t s_blink_level = 0;	// 当前闪烁电平（1=亮）
static uint32_t s_blink_timer = 0;	// 上次翻转的时刻
#endif

// 红灯 开/关（按接法选择输出正确电平）
static void led_red_write(uint8_t on)
{
#if LED_SINK_MODE
	HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, on ? GPIO_PIN_RESET : GPIO_PIN_SET);
#else
	HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET);
#endif
}

// 绿灯 开/关（按接法选择输出正确电平）
static void led_green_write(uint8_t on)
{
#if LED_SINK_MODE
	HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, on ? GPIO_PIN_RESET : GPIO_PIN_SET);
#else
	HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET);
#endif
}

// 初始化：全部熄灭（测试模式下两个灯常亮）
void led_init(void)
{
#if LED_TEST_ALWAYS_ON
	led_green_write(1);		// 测试：绿灯常亮
	led_red_write(1);		// 测试：红灯常亮
#else
	led_off();
#endif
}

// 全部熄灭（同时停止慢闪）
void led_off(void)
{
#if !LED_TEST_ALWAYS_ON
	s_blink_on = 0;
	s_blink_level = 0;
	led_red_write(0);
	led_green_write(0);
#endif
}

// 绿灯亮（红灯灭）
void led_green(void)
{
#if !LED_TEST_ALWAYS_ON
	s_blink_on = 0;
	led_red_write(0);
	led_green_write(1);
#endif
}

// 红灯亮（绿灯灭）
void led_red(void)
{
#if !LED_TEST_ALWAYS_ON
	s_blink_on = 0;
	led_green_write(0);
	led_red_write(1);
#endif
}

// 慢闪开关：on=1 红灯慢闪；on=0 停止并全部熄灭
void led_blink(uint8_t on)
{
#if !LED_TEST_ALWAYS_ON
	if (on)
	{
		s_blink_on = 1;
		s_blink_level = 1;
		s_blink_timer = HAL_GetTick();
		led_green_write(0);
		led_red_write(1);		// 先亮起来，之后每 500ms 翻转
	}
	else
	{
		led_off();
	}
#else
	(void)on;		// 测试模式用不到这个参数
#endif
}

// 主循环里调用：处理慢闪计时
void led_task(void)
{
#if !LED_TEST_ALWAYS_ON
	if (!s_blink_on)
	{
		return;
	}
	if ((int32_t)(HAL_GetTick() - s_blink_timer) >= LED_BLINK_MS)
	{
		s_blink_timer += LED_BLINK_MS;
		s_blink_level = (uint8_t)(!s_blink_level);
		led_red_write(s_blink_level);
	}
#endif
}
