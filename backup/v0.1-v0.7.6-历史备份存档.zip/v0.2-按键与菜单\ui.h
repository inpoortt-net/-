#pragma once
#include"main.h"

// 时间结构体：weekday 的取值 0=周日、1=周一、……、6=周六
typedef struct
{
	uint16_t year;		// 年，如 2026
	uint8_t month;		// 月，1~12
	uint8_t day;		// 日，1~31
	uint8_t hour;		// 时，0~23
	uint8_t minute;		// 分，0~59
	uint8_t second;		// 秒，0~59
	uint8_t weekday;	// 星期，0=周日 ~ 6=周六
} ui_time_t;

// ================== 对外接口 ==================
void ui_init(void);			// 初始化界面（屏幕初始化 + 时钟初始化 + 画第一屏）
void ui_task(void);			// 在主循环里反复调用：负责走时和刷新屏幕
void ui_clock_set(uint16_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t minute, uint8_t second);	// 设置时间（以后做按键校时用）
const ui_time_t *ui_clock_get(void);	// 读取当前时间（返回的是内部结构体的指针，只读用）
