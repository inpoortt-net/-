// settings.c —— 系统设置存储（目前只有“密码”一项）
// 存在 Flash 的 0x0800F800 这一页（倒数第二页），方法和 clock.c 的存储一样：
// 一页 64 个格子，一个个往后写，写满整页擦掉重来
#include"settings.h"

// ================== 存储相关参数 ==================
#define SETTINGS_FLASH_ADDR	0x0800F800UL	// Flash 倒数第二页（1KB，本模块专用）
#define SETTINGS_SLOT_SIZE	16				// 一条记录占 16 字节
#define SETTINGS_SLOT_COUNT	64				// 一页存 64 条（存满了整页擦掉重来）
#define SETTINGS_MAGIC		0x50574431UL	// 魔数（'PWD1'），判断格子里有没有数据

// 默认密码：第一次上电、或者 Flash 里没有记录时用（想改就改这一行）
static const uint8_t s_default_pwd[] = { 1, 2, 3, 4 };

// 一条密码记录（16 字节）
typedef struct
{
	uint32_t magic;						// 等于 SETTINGS_MAGIC 表示有数据；全 0xFFFFFFFF 表示空格子
	uint8_t len;						// 密码位数（4~8）
	uint8_t digits[SETTINGS_PWD_MAX];	// 各位数字
	uint8_t checksum;					// 前面 13 个字节相加的低 8 位（防写坏）
	uint8_t reserved[2];				// 补满 16 字节
} settings_slot_t;

// 编译期检查：结构体必须正好 16 字节（如果以后改字段改坏了，这里会直接编译报错）
typedef char settings_slot_size_check[(sizeof(settings_slot_t) == SETTINGS_SLOT_SIZE) ? 1 : -1];

static uint8_t s_password[SETTINGS_PWD_MAX];	// 当前密码
static uint8_t s_password_len;					// 当前密码位数

// 一条记录的校验和：前 13 个字节相加
static uint8_t settings_slot_checksum(const settings_slot_t *slot)
{
	const uint8_t *p = (const uint8_t *)slot;
	uint8_t sum = 0;
	uint8_t i;

	for (i = 0; i < 13; i++)
	{
		sum = (uint8_t)(sum + p[i]);
	}
	return sum;
}

// 从 Flash 里读密码；找到合法记录返回 1，没有返回 0
static uint8_t settings_flash_load(void)
{
	int8_t i;
	uint8_t j;

	for (i = (int8_t)(SETTINGS_SLOT_COUNT - 1); i >= 0; i--)
	{
		const settings_slot_t *s = (const settings_slot_t *)(SETTINGS_FLASH_ADDR + (uint32_t)i * SETTINGS_SLOT_SIZE);

		if (s->magic == SETTINGS_MAGIC &&
			s->checksum == settings_slot_checksum(s) &&
			s->len >= 4 && s->len <= SETTINGS_PWD_MAX)
		{
			for (j = 0; j < s->len; j++)
			{
				if (s->digits[j] > 9)
				{
					break;	// 数据不合法
				}
			}
			if (j == s->len)
			{
				for (j = 0; j < SETTINGS_PWD_MAX; j++)
				{
					s_password[j] = (j < s->len) ? s->digits[j] : 0;
				}
				s_password_len = s->len;
				return 1;
			}
		}
	}
	return 0;
}

// 把密码写进 Flash：从前往后找空格子，填进去；没有空格子了就擦掉整页重来
static void settings_flash_save(const uint8_t *digits, uint8_t len)
{
	settings_slot_t slot;
	FLASH_EraseInitTypeDef erase;
	uint32_t page_error = 0;
	uint32_t addr = SETTINGS_FLASH_ADDR;
	const uint16_t *p;
	uint8_t i;
	uint8_t need_erase = 1;

	// 1. 找第一个还没写过的格子
	for (i = 0; i < SETTINGS_SLOT_COUNT; i++)
	{
		const settings_slot_t *s = (const settings_slot_t *)(SETTINGS_FLASH_ADDR + (uint32_t)i * SETTINGS_SLOT_SIZE);

		if (s->magic == 0xFFFFFFFFUL)
		{
			addr = SETTINGS_FLASH_ADDR + (uint32_t)i * SETTINGS_SLOT_SIZE;
			need_erase = 0;
			break;
		}
	}

	// 2. 把密码装进记录
	slot.magic = SETTINGS_MAGIC;
	slot.len = len;
	for (i = 0; i < SETTINGS_PWD_MAX; i++)
	{
		slot.digits[i] = (i < len) ? digits[i] : 0;
	}
	slot.checksum = 0;
	slot.reserved[0] = 0;
	slot.reserved[1] = 0;
	slot.checksum = settings_slot_checksum(&slot);

	// 3. 开写
	HAL_FLASH_Unlock();

	if (need_erase)
	{
		erase.TypeErase = FLASH_TYPEERASE_PAGES;
		erase.PageAddress = SETTINGS_FLASH_ADDR;
		erase.NbPages = 1;
		if (HAL_FLASHEx_Erase(&erase, &page_error) != HAL_OK)
		{
			HAL_FLASH_Lock();
			return;
		}
		addr = SETTINGS_FLASH_ADDR;
	}

	p = (const uint16_t *)&slot;
	for (i = 0; i < (uint8_t)(SETTINGS_SLOT_SIZE / 2); i++)
	{
		if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, addr + (uint32_t)i * 2, p[i]) != HAL_OK)
		{
			break;	// 写失败就停（下次上电校验不过会跳过这条）
		}
	}

	HAL_FLASH_Lock();
}

// 上电初始化
void settings_init(void)
{
	uint8_t i;

	if (settings_flash_load())
	{
		return;		// 找到以前存的密码，直接用
	}
	// 第一次上电：用默认密码，并存一份（下次上电就能读到了）
	for (i = 0; i < SETTINGS_PWD_MAX; i++)
	{
		s_password[i] = (i < (uint8_t)sizeof(s_default_pwd)) ? s_default_pwd[i] : 0;
	}
	s_password_len = (uint8_t)sizeof(s_default_pwd);
	settings_flash_save(s_password, s_password_len);
}

// 读出当前密码
void settings_get_password(uint8_t *digits, uint8_t *len)
{
	uint8_t i;

	for (i = 0; i < SETTINGS_PWD_MAX; i++)
	{
		digits[i] = s_password[i];
	}
	*len = s_password_len;
}

// 保存新密码（先存内存，再写 Flash）
void settings_set_password(const uint8_t *digits, uint8_t len)
{
	uint8_t i;

	if (len < 4 || len > SETTINGS_PWD_MAX)
	{
		return;		// 位数不合法，忽略（调用方应该先检查）
	}
	for (i = 0; i < SETTINGS_PWD_MAX; i++)
	{
		s_password[i] = (i < len) ? digits[i] : 0;
	}
	s_password_len = len;
	settings_flash_save(digits, len);
}
