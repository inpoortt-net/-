// key.c —— 4 个按键的驱动
// 引脚：PA0=UP、PA1=DOWN、PA2=OK、PA3=BACK（CubeMX 已配好“输入 + 内部上拉”，按下是低电平）
// 用法：key_tick() 放进 SysTick 中断（1ms 一次）；主循环用 key_get_event() 取事件
// 三种事件：短按 / 长按 / 连发（连发用于“按住不放快速滚动”）
#include"key.h"

// ================== 参数（想改手感就改这里） ==================
#define KEY_SCAN_MS			10		// 每 10ms 扫描一次按键
#define KEY_DEBOUNCE		3		// 连续 3 次一样才算稳定（3x10ms=30ms，消抖）
#define KEY_LONG_SCANS		80		// 按住 80x10ms = 800ms：触发长按
#define KEY_REPEAT_SCANS	20		// 长按后每 20x10ms = 200ms：触发一次连发

#define KEY_QUEUE_SIZE		8		// 事件队列大小（必须是 2 的幂）

// ================== 内部变量 ==================
static GPIO_TypeDef *const s_key_port[KEY_COUNT] =
{
	KEY_UP_GPIO_Port, KEY_DOWN_GPIO_Port, KEY_OK_GPIO_Port, KEY_BACK_GPIO_Port
};
static const uint16_t s_key_pin[KEY_COUNT] =
{
	KEY_UP_Pin, KEY_DOWN_Pin, KEY_OK_Pin, KEY_BACK_Pin
};

// 每个按键自己的状态机数据
typedef struct
{
	uint8_t stable;			// 当前稳定的电平：0=松开，1=按下
	uint8_t raw_cnt;		// 电平变化的连续次数（消抖用）
	uint16_t hold_cnt;		// 按住时长（单位：扫描次数，1 次 = 10ms）
	uint8_t long_sent;		// 长按事件已经发过了吗
	uint8_t repeat_cnt;		// 连发计时
} key_state_t;

static key_state_t s_keys[KEY_COUNT];
static uint8_t s_scan_div = 0;		// 把 1ms 分频成 10ms 用

// 事件队列：中断里往里放，主循环往外取（一放一取，不用加锁）
// 每个事件打包成一个 16 位数：高 8 位=事件类型，低 8 位=按键编号
static volatile uint16_t s_queue[KEY_QUEUE_SIZE];
static volatile uint8_t s_q_head = 0;
static volatile uint8_t s_q_tail = 0;

// 往队列里放一个事件（队列满了就丢弃，正常用不会满）
static void key_push(uint8_t key, uint8_t event)
{
	uint8_t next = (uint8_t)((s_q_head + 1) & (KEY_QUEUE_SIZE - 1));

	if (next != s_q_tail)
	{
		s_queue[s_q_head] = (uint16_t)(((uint16_t)event << 8) | key);
		s_q_head = next;
	}
}

// 扫描一个按键（每 10ms 调一次）
static void key_scan_one(uint8_t idx)
{
	key_state_t *k = &s_keys[idx];
	uint8_t raw;

	// 读引脚：低电平 = 按下
	raw = (HAL_GPIO_ReadPin(s_key_port[idx], s_key_pin[idx]) == GPIO_PIN_RESET) ? 1 : 0;

	if (raw != k->stable)
	{
		// 电平变了，先数够 3 次再说（消抖）
		k->raw_cnt++;
		if (k->raw_cnt >= KEY_DEBOUNCE)
		{
			k->raw_cnt = 0;
			k->stable = raw;
			if (raw)
			{
				// 刚按下：重新开始计时
				k->hold_cnt = 0;
				k->long_sent = 0;
				k->repeat_cnt = 0;
			}
			else if (!k->long_sent)
			{
				// 刚松开，而且没发过长按，才算一次“短按”
				key_push(idx, KEY_EVENT_SHORT);
			}
		}
	}
	else
	{
		k->raw_cnt = 0;
	}

	if (k->stable)
	{
		// 按住期间：计时，到点了发长按/连发
		if (k->hold_cnt < 0xFFFF)
		{
			k->hold_cnt++;
		}
		if (!k->long_sent && k->hold_cnt >= KEY_LONG_SCANS)
		{
			key_push(idx, KEY_EVENT_LONG);
			k->long_sent = 1;
			k->repeat_cnt = 0;
		}
		else if (k->long_sent)
		{
			k->repeat_cnt++;
			if (k->repeat_cnt >= KEY_REPEAT_SCANS)
			{
				key_push(idx, KEY_EVENT_REPEAT);
				k->repeat_cnt = 0;
			}
		}
	}
}

// 初始化：清空状态和队列（引脚的初始化在 CubeMX 生成的 MX_GPIO_Init 里）
void key_init(void)
{
	uint8_t i;

	for (i = 0; i < KEY_COUNT; i++)
	{
		s_keys[i].stable = 0;
		s_keys[i].raw_cnt = 0;
		s_keys[i].hold_cnt = 0;
		s_keys[i].long_sent = 0;
		s_keys[i].repeat_cnt = 0;
	}
	s_scan_div = 0;
	s_q_head = 0;
	s_q_tail = 0;
}

// 每 1ms 调一次（放在 SysTick 中断里），内部自己分频成 10ms 扫一轮
void key_tick(void)
{
	uint8_t i;

	s_scan_div++;
	if (s_scan_div < KEY_SCAN_MS)
	{
		return;
	}
	s_scan_div = 0;

	for (i = 0; i < KEY_COUNT; i++)
	{
		key_scan_one(i);
	}
}

// 主循环取事件：取到返回 1，并把按键号和事件类型填进 *key / *event；没有事件返回 0
uint8_t key_get_event(uint8_t *key, uint8_t *event)
{
	uint16_t v;

	if (s_q_head == s_q_tail)
	{
		return 0;
	}
	v = s_queue[s_q_tail];
	s_q_tail = (uint8_t)((s_q_tail + 1) & (KEY_QUEUE_SIZE - 1));
	*key = (uint8_t)(v & 0xFF);
	*event = (uint8_t)(v >> 8);
	return 1;
}
