// led.c —— 红/绿状态指示灯
// 红灯=PB1、绿灯=PA4（都配成推挽输出，高电平点亮；各自串了限流电阻）
// 用途：密码正确亮绿灯、错误亮红灯、锁定 30 秒期间红灯慢闪
// 非阻塞：闪烁用“看时刻”的方式在主循环里翻转，不用延时等待
#include"led.h"

#define LED_BLINK_MS	500		// 慢闪周期：每 500ms 翻转一次

static uint8_t s_blink_on = 0;		// 慢闪模式开着吗
static uint8_t s_blink_level = 0;	// 当前闪烁电平（1=亮）
static uint32_t s_blink_timer = 0;	// 上次翻转的时刻

// 红灯 开/关
static void led_red_write(uint8_t on)
{
	HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

// 绿灯 开/关
static void led_green_write(uint8_t on)
{
	HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

// 初始化：全部熄灭
void led_init(void)
{
	led_off();
}

// 全部熄灭（同时停止慢闪）
void led_off(void)
{
	s_blink_on = 0;
	s_blink_level = 0;
	led_red_write(0);
	led_green_write(0);
}

// 绿灯亮（红灯灭）
void led_green(void)
{
	s_blink_on = 0;
	led_red_write(0);
	led_green_write(1);
}

// 红灯亮（绿灯灭）
void led_red(void)
{
	s_blink_on = 0;
	led_green_write(0);
	led_red_write(1);
}

// 慢闪开关：on=1 红灯慢闪；on=0 停止并全部熄灭
void led_blink(uint8_t on)
{
	if (on)
	{
		s_blink_on = 1;
		s_blink_level = 1;
		s_blink_timer = HAL_GetTick();
		led_green_write(0);
		led_red_write(1);		// 先亮起来，之后每 500ms 翻转
	}
	else
	{
		led_off();
	}
}

// 主循环里调用：处理慢闪计时
void led_task(void)
{
	if (!s_blink_on)
	{
		return;
	}
	if ((int32_t)(HAL_GetTick() - s_blink_timer) >= LED_BLINK_MS)
	{
		s_blink_timer += LED_BLINK_MS;
		s_blink_level = (uint8_t)(!s_blink_level);
		led_red_write(s_blink_level);
	}
}
