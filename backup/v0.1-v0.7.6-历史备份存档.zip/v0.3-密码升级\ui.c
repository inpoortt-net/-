// ui.c —— 界面层：页面状态机
// 页面关系：主页（时间日期） --OK--> 主菜单列表 --OK--> 密码锁
// 返回：密码锁 / 主菜单 里按 BACK 往回退；主菜单页 30 秒没操作也会自动回主页
#include"ui.h"
#include"oled.h"
#include"key.h"
#include"clock.h"

// ================== 页面相关 ==================
typedef enum
{
	PAGE_HOME = 0,		// 主页：时间 + 日期
	PAGE_MENU,			// 主菜单列表
	PAGE_PASSWORD		// 密码锁
} ui_page_t;

#define MENU_IDLE_HOME_MS	30000	// 主菜单页 30 秒没按键：自动回主页

static ui_page_t s_page = PAGE_HOME;
static uint8_t s_dirty = 1;				// 1=需要重画屏幕
static uint32_t s_last_tick = 0;		// 上次走时的滴答
static uint32_t s_last_key_tick = 0;	// 最近一次按键的滴答（自动回主页用）

// ================== 主菜单列表 ==================
// 现在只有“密码锁”一项。以后加功能：1) 这里加名字  2) ui_menu_key() 里加分支
#define MENU_ITEM_COUNT		1
#define MENU_VISIBLE		3		// 屏幕中间最多显示几条（每条 16 像素高）

static const char *const s_menu_names[MENU_ITEM_COUNT] = { "Password Lock" };
static uint8_t s_menu_sel = 0;		// 当前选中的是第几项
static uint8_t s_menu_top = 0;		// 列表从第几项开始显示

// ================== 密码锁页 ==================
#define PWD_MIN_LEN			4		// 提交时至少几位
#define PWD_MAX_LEN			8		// 最多能输入几位
#define PWD_RESULT_MS		2000	// “正确/错误”显示多久（毫秒）
#define PWD_HINT_MS			1500	// “至少 4 位”提示显示多久（毫秒）

// 默认密码：想改密码就改这一行（位数在 4~8 之间）
static const uint8_t s_password[] = { 1, 2, 3, 4 };

typedef enum
{
	PWD_STATE_WAIT = 0,		// 等待输入（0 位）
	PWD_STATE_INPUT,		// 输入中
	PWD_STATE_OK,			// 密码正确（展示中）
	PWD_STATE_FAIL			// 密码错误（展示中）
} pwd_state_t;

static pwd_state_t s_pwd_state = PWD_STATE_WAIT;
static uint8_t s_pwd_digits[PWD_MAX_LEN];	// 已确认的数字
static uint8_t s_pwd_count = 0;				// 已输入几位
static uint8_t s_pwd_current = 0;			// 当前正在调的数字 0~9
static uint32_t s_pwd_timer = 0;			// 结果展示的截止时刻
static uint32_t s_pwd_hint_timer = 0;		// 提示的截止时刻

static const char *const s_week_names[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

// 提前声明（下面的函数互相调用）
static void ui_pwd_reset(void);

// ================== 小工具 ==================

// 时间到点了吗？deadline 用 HAL_GetTick() + 时长 先算好
static uint8_t ui_time_up(uint32_t deadline)
{
	return ((int32_t)(HAL_GetTick() - deadline) >= 0) ? 1 : 0;
}

// 把 v 按固定宽度 w 写成十进制数字（例如 v=7、w=2 写成 "07"）
static void ui_num_to_str(char *buf, uint16_t v, uint8_t w)
{
	int8_t i;

	for (i = (int8_t)(w - 1); i >= 0; i--)
	{
		buf[i] = (char)('0' + v % 10);
		v = (uint16_t)(v / 10);
	}
}

// 在第 y 行水平居中显示字符串（color=1 黑底白字；color=0 白底黑字）
static void ui_show_center(uint8_t y, const char *str, uint8_t color)
{
	uint8_t len = 0;
	uint8_t x;

	while (str[len] != '\0')
	{
		len++;
	}
	if ((uint16_t)len * 8 >= OLED_WIDTH)
	{
		x = 0;
	}
	else
	{
		x = (uint8_t)((OLED_WIDTH - len * 8) / 2);
	}
	oled_show_string(x, y, str, color);
}

// ================== 主页 ==================

static void ui_home_key(uint8_t key, uint8_t event)
{
	if (key == KEY_OK && event == KEY_EVENT_SHORT)
	{
		// 进主菜单
		s_page = PAGE_MENU;
		s_menu_sel = 0;
		s_menu_top = 0;
		s_dirty = 1;
	}
}

static void ui_home_draw(void)
{
	const clock_time_t *t = clock_get();
	char buf[17];
	const char *week;

	oled_clear();

	// 标题栏
	oled_fill_rect(0, 0, OLED_WIDTH, 16, 1);
	ui_show_center(0, "MAIN MENU", 0);

	// 时间行 "hh:mm:ss"
	ui_num_to_str(buf, t->hour, 2);
	buf[2] = ':';
	ui_num_to_str(buf + 3, t->minute, 2);
	buf[5] = ':';
	ui_num_to_str(buf + 6, t->second, 2);
	buf[8] = '\0';
	ui_show_center(16, buf, 1);

	// 日期行 "yyyy-mm-dd Www"
	ui_num_to_str(buf, t->year, 4);
	buf[4] = '-';
	ui_num_to_str(buf + 5, t->month, 2);
	buf[7] = '-';
	ui_num_to_str(buf + 8, t->day, 2);
	buf[10] = ' ';
	week = s_week_names[t->weekday % 7];
	buf[11] = week[0];
	buf[12] = week[1];
	buf[13] = week[2];
	buf[14] = '\0';
	ui_show_center(32, buf, 1);

	// 底部提示
	ui_show_center(48, "PRESS OK: MENU", 1);
}

// ================== 主菜单列表页 ==================

// 上下移动后，保证选中的项留在可见范围里（以后列表长了会自动滚动）
static void ui_menu_keep_visible(void)
{
	if (s_menu_sel < s_menu_top)
	{
		s_menu_top = s_menu_sel;
	}
	else if (s_menu_sel >= (uint8_t)(s_menu_top + MENU_VISIBLE))
	{
		s_menu_top = (uint8_t)(s_menu_sel - MENU_VISIBLE + 1);
	}
}

static void ui_menu_key(uint8_t key, uint8_t event)
{
	switch (key)
	{
	case KEY_UP:
		s_menu_sel = (uint8_t)((s_menu_sel + MENU_ITEM_COUNT - 1) % MENU_ITEM_COUNT);
		ui_menu_keep_visible();
		s_dirty = 1;
		break;
	case KEY_DOWN:
		s_menu_sel = (uint8_t)((s_menu_sel + 1) % MENU_ITEM_COUNT);
		ui_menu_keep_visible();
		s_dirty = 1;
		break;
	case KEY_OK:
		if (event == KEY_EVENT_SHORT)
		{
			if (s_menu_sel == 0)
			{
				// 进入“密码锁”
				ui_pwd_reset();
				s_page = PAGE_PASSWORD;
				s_dirty = 1;
			}
		}
		break;
	case KEY_BACK:
		s_page = PAGE_HOME;
		s_dirty = 1;
		break;
	default:
		break;
	}
}

static void ui_menu_draw(void)
{
	uint8_t row;
	uint8_t idx;
	uint8_t y;

	oled_clear();

	// 标题栏
	oled_fill_rect(0, 0, OLED_WIDTH, 16, 1);
	ui_show_center(0, "MENU", 0);

	// 列表：选中的一项反白（白底黑字）
	for (row = 0; row < MENU_VISIBLE; row++)
	{
		idx = (uint8_t)(s_menu_top + row);
		y = (uint8_t)(16 + row * 16);
		if (idx >= MENU_ITEM_COUNT)
		{
			break;
		}
		if (idx == s_menu_sel)
		{
			oled_fill_rect(0, y, OLED_WIDTH, 16, 1);
			oled_show_string(8, y, s_menu_names[idx], 0);
		}
		else
		{
			oled_show_string(8, y, s_menu_names[idx], 1);
		}
	}
}

// ================== 密码锁页 ==================

// 回到“等待输入”：清空所有数字和提示
static void ui_pwd_reset(void)
{
	uint8_t i;

	for (i = 0; i < PWD_MAX_LEN; i++)
	{
		s_pwd_digits[i] = 0;
	}
	s_pwd_count = 0;
	s_pwd_current = 0;
	s_pwd_state = PWD_STATE_WAIT;
	s_pwd_hint_timer = 0;
}

// 提交校验（长按 OK 时调用）
static void ui_pwd_submit(void)
{
	uint8_t ok = 1;
	uint8_t i;

	// 不足 4 位不给提交，只提示
	if (s_pwd_count < PWD_MIN_LEN)
	{
		s_pwd_hint_timer = HAL_GetTick() + PWD_HINT_MS;
		return;
	}

	if (s_pwd_count != (uint8_t)sizeof(s_password))
	{
		ok = 0;
	}
	else
	{
		for (i = 0; i < s_pwd_count; i++)
		{
			if (s_pwd_digits[i] != s_password[i])
			{
				ok = 0;
				break;
			}
		}
	}

	s_pwd_state = ok ? PWD_STATE_OK : PWD_STATE_FAIL;
	s_pwd_timer = HAL_GetTick() + PWD_RESULT_MS;
	s_dirty = 1;
}

static void ui_pwd_key(uint8_t key, uint8_t event)
{
	// 结果展示的 2 秒里，按键全部忽略（防止手快误触下一轮）
	if (s_pwd_state == PWD_STATE_OK || s_pwd_state == PWD_STATE_FAIL)
	{
		return;
	}

	switch (key)
	{
	case KEY_UP:
		// 短按一格一格调；按住连发快速滚动
		s_pwd_current = (uint8_t)((s_pwd_current + 1) % 10);
		s_dirty = 1;
		break;
	case KEY_DOWN:
		s_pwd_current = (uint8_t)((s_pwd_current + 9) % 10);
		s_dirty = 1;
		break;
	case KEY_OK:
		if (event == KEY_EVENT_SHORT)
		{
			// 确认当前位，跳到下一位
			if (s_pwd_count < PWD_MAX_LEN)
			{
				s_pwd_digits[s_pwd_count] = s_pwd_current;
				s_pwd_count++;
				s_pwd_current = 0;
				s_pwd_state = PWD_STATE_INPUT;
				s_dirty = 1;
			}
		}
		else if (event == KEY_EVENT_LONG)
		{
			// 长按提交校验
			ui_pwd_submit();
		}
		break;
	case KEY_BACK:
		if (event == KEY_EVENT_SHORT)
		{
			if (s_pwd_count > 0)
			{
				// 删除最后一位，并把它捡回来继续调
				s_pwd_count--;
				s_pwd_current = s_pwd_digits[s_pwd_count];
				s_pwd_state = (s_pwd_count == 0) ? PWD_STATE_WAIT : PWD_STATE_INPUT;
				s_dirty = 1;
			}
			else
			{
				// 一位都没输入，按 BACK 回主菜单
				s_page = PAGE_MENU;
				s_dirty = 1;
			}
		}
		else if (event == KEY_EVENT_LONG)
		{
			// 一键清空
			ui_pwd_reset();
			s_dirty = 1;
		}
		break;
	default:
		break;
	}
}

static void ui_pwd_draw(void)
{
	char line[17];
	char msg[17];
	uint8_t i;

	oled_clear();

	// 标题栏
	oled_fill_rect(0, 0, OLED_WIDTH, 16, 1);
	ui_show_center(0, "PASSWORD", 0);

	// 状态行
	switch (s_pwd_state)
	{
	case PWD_STATE_WAIT:
		ui_show_center(16, "WAIT INPUT", 1);
		break;
	case PWD_STATE_INPUT:
		// 拼成 "INPUT 3 DIG"
		msg[0] = 'I';
		msg[1] = 'N';
		msg[2] = 'P';
		msg[3] = 'U';
		msg[4] = 'T';
		msg[5] = ' ';
		ui_num_to_str(&msg[6], s_pwd_count, 1);
		msg[7] = ' ';
		msg[8] = 'D';
		msg[9] = 'I';
		msg[10] = 'G';
		msg[11] = '\0';
		ui_show_center(16, msg, 1);
		break;
	case PWD_STATE_OK:
		ui_show_center(16, "PASSWORD OK", 1);
		break;
	default:
		ui_show_center(16, "PASSWORD ERR", 1);
		break;
	}

	// 数字行：已确认的显示 *，当前位显示正在调的数字，后面显示 _
	for (i = 0; i < PWD_MAX_LEN; i++)
	{
		if (i < s_pwd_count)
		{
			line[i * 2] = '*';
		}
		else if (i == s_pwd_count)
		{
			line[i * 2] = (char)('0' + s_pwd_current);
		}
		else
		{
			line[i * 2] = '_';
		}
		if (i < (PWD_MAX_LEN - 1))
		{
			line[i * 2 + 1] = ' ';
		}
	}
	line[15] = '\0';
	oled_show_string(4, 32, line, 1);

	// 底部提示行
	if (s_pwd_hint_timer != 0 && !ui_time_up(s_pwd_hint_timer))
	{
		ui_show_center(48, "NEED 4+ DIGITS", 1);
	}
	else
	{
		ui_show_center(48, "HOLD OK=SUBMIT", 1);
	}
}

// ================== 页面调度 ==================

static void ui_handle_key(uint8_t key, uint8_t event)
{
	s_last_key_tick = HAL_GetTick();	// 记录按键时刻（自动回主页用）

	switch (s_page)
	{
	case PAGE_HOME:
		ui_home_key(key, event);
		break;
	case PAGE_MENU:
		ui_menu_key(key, event);
		break;
	case PAGE_PASSWORD:
		ui_pwd_key(key, event);
		break;
	default:
		break;
	}
}

static void ui_draw_page(void)
{
	switch (s_page)
	{
	case PAGE_HOME:
		ui_home_draw();
		break;
	case PAGE_MENU:
		ui_menu_draw();
		break;
	case PAGE_PASSWORD:
		ui_pwd_draw();
		break;
	default:
		break;
	}
	oled_refresh();		// 统一在这里把画面推到屏幕
}

// ================== 对外接口 ==================

// 初始化：屏幕 -> 时钟 -> 画第一屏
void ui_init(void)
{
	oled_init();
	clock_init();
	s_page = PAGE_HOME;
	s_dirty = 1;
	s_last_tick = HAL_GetTick();
	s_last_key_tick = HAL_GetTick();
	ui_draw_page();
}

// 主循环任务：处理按键、走时、定时任务、刷新屏幕
void ui_task(void)
{
	uint32_t now;
	uint32_t elapsed;
	uint32_t whole_secs;
	uint8_t key;
	uint8_t event;

	// 1. 处理所有排队的按键事件
	while (key_get_event(&key, &event))
	{
		ui_handle_key(key, event);
	}

	// 2. 走时：攒够 1 秒推 1 秒；主页的时间要跟着刷新
	now = HAL_GetTick();
	elapsed = now - s_last_tick;
	whole_secs = elapsed / 1000;
	if (whole_secs > 0)
	{
		s_last_tick += whole_secs * 1000;
		clock_add_seconds(whole_secs);
		if (s_page == PAGE_HOME)
		{
			s_dirty = 1;
		}
	}

	// 3. 密码结果展示结束 -> 自动清空，回到“等待输入”（可以马上重试）
	if ((s_pwd_state == PWD_STATE_OK || s_pwd_state == PWD_STATE_FAIL) &&
		ui_time_up(s_pwd_timer))
	{
		ui_pwd_reset();
		s_dirty = 1;
	}

	// 4. “至少 4 位”提示到点 -> 恢复成普通提示
	if (s_pwd_hint_timer != 0 && ui_time_up(s_pwd_hint_timer))
	{
		s_pwd_hint_timer = 0;
		s_dirty = 1;
	}

	// 5. 主菜单页长时间没操作 -> 自动回主页
	if (s_page == PAGE_MENU && (uint32_t)(now - s_last_key_tick) > MENU_IDLE_HOME_MS)
	{
		s_page = PAGE_HOME;
		s_dirty = 1;
	}

	// 6. 需要就重画
	if (s_dirty)
	{
		s_dirty = 0;
		ui_draw_page();
	}
}
